-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 10, 2023 at 10:49 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlbh`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `CompID` tinyint(4) NOT NULL auto_increment,
  `CompName` varchar(50) NOT NULL,
  `CompAddress` varchar(100) NOT NULL,
  `CompPhone` varchar(10) default NULL,
  `Email` varchar(50) default NULL,
  PRIMARY KEY  (`CompID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`CompID`, `CompName`, `CompAddress`, `CompPhone`, `Email`) VALUES
(1, 'Ao Thun', '139/7/3 Vuon Lai Q12 HCM', '0375028926', 'nknn2901@gmail.com'),
(2, 'Ao Khoac', '139/7/3 Vuon Lai Q12 HCM', '0375028926', 'nknn2901@gmail.com'),
(3, 'Non', '139/7/3 Vuon Lai Q12 HCM', '0375028926', 'nknn2901@gmail.com'),
(4, 'Tui', '139/7/3 Vuon Lai Q12 HCM', '0375028926', 'nknn2901@gmail.com'),
(5, 'Quan', '139/7/3 Vuon Lai Q12 HCM', '0375028926', 'nknn2901@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ProdID` tinyint(4) NOT NULL auto_increment,
  `ProdName` varchar(50) NOT NULL,
  `ProdPrice` double NOT NULL,
  `ProdImage` varchar(50) NOT NULL,
  `ProdDescription` varchar(50) default NULL,
  `CompID` tinyint(4) NOT NULL,
  PRIMARY KEY  (`ProdID`),
  KEY `CompID` (`CompID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProdID`, `ProdName`, `ProdPrice`, `ProdImage`, `ProdDescription`, `CompID`) VALUES
(1, '2 Lip Tee', 390000, '', 'Chất liệu: Compact', 1),
(2, 'Doraemon Mini Cat Tee', 405000, '', 'Chất liệu: Compact', 1),
(3, 'Inside Out Tree', 312000, '', 'Chất liệu: Compact', 1),
(4, 'Plus Club Tee', 390000, '', 'Chất liệu: Compact', 1),
(5, '3rd Anniversary Tee', 333000, '', 'Chất liệu: Compact', 1),
(6, 'Basic Boxy Hoodie', 600000, '', 'Chất liệu: Fabric - Boxy', 2),
(7, 'Doraemon Collab Zipper Hoodie', 645000, '', 'Chất liệu: Nỉ ', 2),
(8, 'Punch Varsity', 890000, '', 'Chất liệu: Nỉ dạ', 2),
(9, 'Serri Bear Hoodie', 599000, '', 'Chất liệu: Nỉ dạ', 2),
(10, 'Sporty Jacket', 630000, '', 'Chất liệu: Nylon Taslon', 2),
(11, 'Basic Cap', 320000, '', 'Chất liệu: Poly', 3),
(12, 'Basic Cap', 320000, '', 'Chất liệu: Poly', 3),
(13, 'Basic Cap', 320000, '', 'Chất liệu: Poly', 3),
(14, 'Trucker Hat', 320000, '', 'Chất liệu: Poly', 3),
(15, 'Trucker Hat', 320000, '', 'Chất liệu: Poly', 3),
(16, 'Essential Mini Shoulder Bag', 330000, '', 'Chất liệu: Canvas', 4),
(17, '2 Tone Mini Shoulder Bag', 330000, '', 'Chất liệu: Canvas', 4),
(18, '2 Tone Mini Shoulder Bag', 330000, '', 'Chất liệu: Canvas', 4),
(19, '3 rd Anniversary Tote Bag', 420000, '', 'Chất liệu: Canvas', 4),
(20, 'Tote Bag', 100000, '', 'Chất liệu: None - Woven fabric', 4),
(21, 'Play Logo ShortPant', 390000, '', 'Chất liệu: Fabric', 5),
(22, 'Play Logo ShortPant', 390, '', 'Chất liệu: Fabric', 5),
(23, 'Play Logo ShortPant', 390000, '', 'Chất liệu: Fabric', 5),
(24, 'Khaki Pants', 510000, '', 'Chất liệu: Khaki', 5),
(25, 'Space Straight Pants', 450000, '', 'Chất liệu: Parachute (Dù)', 5);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`CompID`) REFERENCES `company` (`CompID`) ON DELETE CASCADE ON UPDATE CASCADE;
